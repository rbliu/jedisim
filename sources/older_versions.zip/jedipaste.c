#include <stdio.h>
#include <math.h>
#include <string.h>
#include "fitsio.h"

#include <time.h>



char *help[] = {
    "usage: jedipaste x y imlist final_image",
    "Arguments: x - width of the final image",
    "           y - height of the final image",
    "           imlist - list of paths of images to insert in to the final image",
    "           final_image - path for the output image. Will overwrite other files.",
    "imlist description: text file of filepaths to valid FITS images to be inserted",
    "into the final image. There must be one filepath per line. The header of each",
    "FITS file must have the entries XEMBED and YEMBED, with integer values giving the",
    "x and y pixel where the lower left corner of the embedded image should be placed.",
    0};

int main(int argc, char *argv[]){

    //check command line input
    if(argc != 5){
        int line;
        for(line = 0; help[line] != 0; line++)
            fprintf(stderr, "%s\n", help[line]);
        exit(1);
    }

    long int    nx, ny;             //width and height of the final image
    FILE        *imlist_file;       //file object for the image list
    char        **imlist;           //array for the images to embed
    long int    nimages;            //number of images int embed
    char        buffer[1024];       //string buffer for reading imlist
    float       *fimage, *image;    //arrays for the final image and the current embedded image
    fitsfile    *ffptr, *efptr;     //final and embed CFITSIO file pointers
    int         status = 0,naxis=0; //CFITSIO status and number of axes parameters
    long        naxes[2], fpixel[2] = {1,1};    //CFITSIO axes lengths and first pixel to read in



    //parse command line arguments
    sscanf(argv[1], "%li", &nx);
    sscanf(argv[2], "%li", &ny);

    //open imlist
    if((imlist_file = fopen(argv[3],"r"))==NULL){
        fprintf(stderr,"Error: could not open image list file \"%s\".\n",argv[3]);
        exit(1);
    }

    //count the number of files in imlist
    nimages = 0;
    while(fscanf(imlist_file, "%s\n", &buffer) >0)
        nimages++;
    fprintf(stdout,"%li images in \"%s\"\n.", nimages, argv[3]);

    //initialize memory for the image names array
    imlist = (char **) calloc(nimages, sizeof(char*));
    if(imlist == NULL){
        fprintf(stdout, "Error: could not allocate memory for the list of image names.");
        exit(1);
    }

    //read in image names
    rewind(imlist_file);
    long int    im;     //image counter
    for(im = 0; im < nimages; im++){
        fscanf(imlist_file, "%s\n", &buffer);
        imlist[im] = (char *) calloc(strlen(buffer)+1, sizeof(char));
        if(imlist[im] == NULL){
            fprintf(stderr,"Error: could not allocate memory for image %i name.", im);
            exit(1);
        }
        strcpy(imlist[im], buffer);
    }

    /*
       for(im = 0; im < nimages; im++){
       fprintf(stdout, "%s\n", imlist[im]);
       }*/


    //create the big image array
    fimage = (float*) calloc(nx*ny, sizeof(float));
    if(fimage == NULL){
        fprintf(stdout,"Error: could not allocate memory for the final image. Try closing some applications or using a different computer with more RAM.");
        exit(1);
    }

    //loop over each image and embed them one at a time

    for(im = 0; im < nimages; im++){

        //read in galaxy image
        fits_open_file(&efptr, imlist[im], READONLY, &status);
        fits_get_img_dim(efptr, &naxis, &status);
        fits_get_img_size(efptr, 2, naxes, &status);
        if(status){
            fits_report_error(stderr, status);
            exit(1);
        }

        //allocate enough memory for the image
        //fprintf(stdout, "Allocating memory for embed image %li: \"%s\".\n", im, imlist[im]);
        image = (float *) calloc (naxes[0]*naxes[1], sizeof(float));
        if (image == NULL){
            fprintf(stderr, "Error allocating memory for galaxy image %i.\n", im);
            exit(1);
        }

        char        xembedstr[32], yembedstr[32];
        long int    xembed, yembed;
        fits_read_key_str(efptr, "XEMBED", xembedstr, NULL, &status);
        fits_read_key_str(efptr, "YEMBED", yembedstr, NULL, &status);
        //fprintf(stdout,"(%s, %s)\n", xembedstr, yembedstr);
        sscanf(xembedstr, "%li", &xembed);
        sscanf(yembedstr, "%li", &yembed);


        //read in the image
        //fprintf(stdout, "Reading in image.\n");
        if(fits_read_pix(efptr, TFLOAT, fpixel, naxes[0]*naxes[1], NULL, image, NULL, &status)){
            fprintf(stderr, "Can't read in embed image %i.\n", im);
            fits_report_error(stderr, status);
            exit(1);
        }
        fits_close_file(efptr, &status);

        //check that the image will fit
        if(xembed + naxes[0] > nx || yembed + naxes[1] > ny){
            fprintf(stderr, "Error: image %i will not fit on the final image. It would have boundaries (xmin: %li, xmax: %li, ymin: %li, ymax: %li).\n", xembed, xembed+naxes[0], yembed, yembed+naxes[1]);
            exit(1);
        }

        long int    row, col;   //counter to embed the image
        for(row = 0; row < naxes[0]; row++){
            for(col = 0; col < naxes[1]; col++){
                fimage[(yembed+col)*nx + (xembed+row)] +=  image[col*naxes[0] + row];
            }
        }
        fprintf(stdout,"Embedding image %i at (%li, %li).\n", im, xembed, yembed);
        free(image);
    }

    long int fnaxes[2] = {nx, ny};

    fprintf(stdout,"Writing output image %s. This may take several minutes.\n", argv[4]);
    fits_create_file(&ffptr, argv[4], &status);
    fits_create_img(ffptr, FLOAT_IMG, naxis, fnaxes, &status);
    fits_write_pix(ffptr, TFLOAT, fpixel, nx*ny, fimage, &status);
    fits_close_file(ffptr, &status);
    fits_report_error(stderr, status);

    free(fimage);
    return 0;
}
