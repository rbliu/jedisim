#include <stdio.h>
#include <math.h>
#include "fitsio.h"

 /* convolves the given postage stamp with the given PSF
  *
 */


char *help[] = {"usage: jediconvolve input_file PSF_file output_file",
    "PSF_file must have an odd number of rows and columns",0};


int main(int argc, char *argv[]){

    if(argc != 4){
        int line;
        for(line = 0; help[line] !=0; line++)
            fprintf(stderr,"%s\n", help[line]);
        exit(1);
    }



    fitsfile *ifptr, *pfptr, *ofptr;
    int status = 0;
    int naxis = 0;
    long int inaxes[2], pnaxes[2], onaxes[2];
    long int fpixel[2] = {1,1};
    float *image, *image2, *pimage, *oimage;


    //read in galaxy image
    fits_open_file(&ifptr, argv[1], READONLY, &status);
    fits_get_img_dim(ifptr, &naxis, &status);
    fits_get_img_size(ifptr, 2, inaxes, &status);
    if(status){
        fits_report_error(stderr, status);
        exit(1);
    }

    //allocate enough memory for the image
    //fprintf(stdout, "Allocating memory for image \"%s\".\n", argv[1]);
    image = (float *) calloc (inaxes[0]*inaxes[1], sizeof(float));
    if (image == NULL){
        fprintf(stderr, "Error allocating memory for image.\n");
        exit(1);
    }

    //read in the image
    if(fits_read_pix(ifptr, TFLOAT, fpixel, inaxes[0]*inaxes[1], NULL, image, NULL, &status)){
        fprintf(stderr, "Can't read in image.\n");
        fits_report_error(stderr, status);
        exit(1);
    }

    char        xembedstr[32], yembedstr[32];
    long int    xembed, yembed;
    fits_read_key_str(ifptr, "XEMBED", xembedstr, NULL, &status);
    fits_read_key_str(ifptr, "YEMBED", yembedstr, NULL, &status);
    
    sscanf(xembedstr, "%li", &xembed);
    sscanf(yembedstr, "%li", &yembed);

    //fprintf(stdout, "Read in input image.\n");
    fits_close_file(ifptr, &status);

    //fprintf(stdout,"(%i, %i)", xembed, yembed);


    //read in PSF image
    fits_open_file(&pfptr, argv[2], READONLY, &status);
    fits_get_img_dim(pfptr, &naxis, &status);
    fits_get_img_size(pfptr, 2, pnaxes, &status);
    if(status){
        fits_report_error(stderr, status);
        exit(1);
    }

    //check that the PSF has odd rows and columns
    if(pnaxes[0] & 1 == 0 || pnaxes[1] & 1 == 0){
        fprintf(stderr, "Error: the PSF image must have an odd number of rows and columns. It's shape is (%i, %i).", pnaxes[0], pnaxes[1]);
        exit(1);
    }

    //allocate enough memory for the PSF
    //fprintf(stdout, "Allocating memory for image \"%s\".\n", argv[1]);
    pimage = (float *) calloc (pnaxes[0]*pnaxes[1], sizeof(float));
    if (pimage == NULL){
        fprintf(stderr, "Error allocating memory for image.\n");
        exit(1);
    }

    //read in the PSF
    if(fits_read_pix(pfptr, TFLOAT, fpixel, pnaxes[0]*pnaxes[1], NULL, pimage, NULL, &status)){
        fprintf(stderr, "Can't read in image.\n");
        fits_report_error(stderr, status);
        exit(1);
    }
    //fprintf(stdout, "Read in PSF.\n");
    fits_close_file(pfptr, &status);

    int kx = pnaxes[0]/2, ky = pnaxes[0]/2;//half the width and height of the kernel
    
    //make image2 with a border of the size of the kernel
    onaxes[0] = inaxes[0] + 2*kx;
    onaxes[1] = inaxes[1] + 2*ky;

    image2 = (float *) calloc(onaxes[0]*onaxes[1], sizeof(float));
    if(image2 == NULL){
        fprintf(stderr, "Error allocating memory for image.\n");
        exit(1);
    }

    //make image2 with image in the center
    long int row, col;
    for(row = 0; row < inaxes[0]; row++){
        for(col = 0; col < inaxes[1]; col++){
            image2[(col+ky)*onaxes[0]+(row+kx)] = image[col*inaxes[0]+row];
        }
    }

    free(image);

    //make the output image
    oimage = (float *) calloc(onaxes[0]*onaxes[1], sizeof(float));
    if(oimage == NULL){
        fprintf(stderr, "Error allocating memory for output image.\n");
        exit(1);
    }

    

    //loop over the output image
    for(row = 0; row < onaxes[0]; row++){
        for(col = 0; col < onaxes[1]; col++){
            //find the box to loop over that contains information
            //this is the intersection of the kernel (when centered at (row, col))
            //and image and embedded in image2
            int xmin = (row - kx < 0 ? -row : -kx);
            int xmax = (row + kx >= onaxes[0] ? onaxes[0]-row-1 : kx);

            int ymin = (col - ky < 0 ? -col : -ky);
            int ymax = (col + ky >= onaxes[1] ? onaxes[1]-col-1 : ky);

            float total = 0;
            int ox, oy;
            for(ox = xmin; ox <= xmax; ox++){
                for(oy = ymin; oy <= ymax; oy++){
                    total += image2[(col+oy)*onaxes[0] + (row+ox)]*pimage[(ky+oy)*pnaxes[0]+(kx+ox)];
                }
            }
            oimage[col*onaxes[0]+row] = total;
        }
    }
    xembed -= kx;
    yembed -= ky;

    //write out output image 
    fits_create_file(&ofptr, argv[3], &status);
    fits_create_img(ofptr, FLOAT_IMG, naxis, onaxes, &status);
    fits_update_key(ofptr, TLONG, "XEMBED", &xembed , "x pixel in target image to embed lower left pixel.", &status);
    fits_update_key(ofptr, TLONG, "YEMBED", &yembed , "y pixel in target image to embed lower left pixel.", &status);
    fits_write_pix(ofptr, TFLOAT, fpixel, onaxes[0]*onaxes[1], oimage, &status);
    fits_close_file(ofptr, &status);
    fits_report_error(stderr, status);
    return 0;
}
