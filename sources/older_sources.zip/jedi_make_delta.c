#include <stdio.h>
#include <math.h>
#include "fitsio.h"

 /* makes a delta function FITS image  *
 */


char *help[] = {"usage: jedi_make_delta output_file",0};


int main(int argc, char *argv[]){

    if(argc != 2){
        int line;
        for(line = 0; help[line] !=0; line++)
            fprintf(stderr,"%s\n", help[line]);
        exit(1);
    }

    fitsfile *ofptr;
    int status = 0;
    int naxis = 2;
    long int  onaxes[2];
    long int fpixel[2] = {1,1};
    float *oimage;

    int size = 11;
    onaxes[0] = size;
    onaxes[1] = size;

    oimage = (float *) calloc(onaxes[0]*onaxes[1], sizeof(float));
    int xc = size/2, yc = size/2;

    fprintf(stdout, "%i", yc*onaxes[0]+xc);
    oimage[yc*onaxes[0] + xc] = 1;

    //write out output image 
    fits_create_file(&ofptr, argv[1], &status);
    fits_create_img(ofptr, FLOAT_IMG, naxis, onaxes, &status);
    fits_write_pix(ofptr, TFLOAT, fpixel, onaxes[0]*onaxes[1], oimage, &status);
    fits_close_file(ofptr, &status);
    fits_report_error(stderr, status);
    
    return 0;
}
