#include <stdio.h>
#include <math.h>
#include "fitsio.h"
#include <fftw3.h>
#include <string.h>

/* convolves the list of postage stamps with the given PSF 
 * uses FFTW to convolve quickly
 */


char *help[] = {"usage: jediconvolve3 convlist PSF",
    "       convlist - textfile that lists filepaths",
    "       convlist: input_file output_file [tab separated]",
    "               input_file - FITS file to convolve",
    "               output_file - file to save convolved image",
    "       PSF - FITS file for the PSF, must have odd width and height",
    0};

typedef struct{
    char input_file[1024];
    char output_file[1024];
} Galaxy;

int main(int argc, char *argv[]){

    if(argc != 3){
        int line;
        for(line = 0; help[line] !=0; line++)
            fprintf(stderr,"%s\n", help[line]);
        exit(1);
    }


    char        convlist_file[1024], PSF_file[1024];
    FILE        *convlist_fp;
    long int    ngalaxies;
    Galaxy      *galaxies;
    char        buffer[1024];   //buffer for reading in  convlist

    //FITS variables
    fitsfile    *ifptr, *pfptr, *ofptr;
    int         status = 0;
    int         naxis = 0;
    long int    inaxes[2], pnaxes[2], onaxes[2];
    long int    fpixel[2] = {1,1};
    float       *image, *pimage, *oimage;

    //get file paths
    sscanf(argv[1], "%s", convlist_file);
    sscanf(argv[2], "%s", PSF_file);

    //figure out how many galaxies there are
    convlist_fp = fopen(convlist_file,"r");
    if(convlist_fp == NULL){
        fprintf(stderr,"Error: could not read convlist file: %s.\n", convlist_file);
        exit(1);
    }

    ngalaxies = 0;
    while(fgets(buffer, 1024, convlist_fp) != NULL)
        ngalaxies++;

    //allocate memory for all the galaxies
    galaxies = (Galaxy *) calloc(ngalaxies, sizeof(Galaxy));
    if(galaxies ==NULL){
        fprintf(stderr, "Error: could not allocate galaxies array.\n");
    }
    rewind(convlist_fp);

    //read in the convlist_file to galaxies array

    long int gal;
    for(gal = 0; gal < ngalaxies; gal++){
        fgets(buffer, 1024, convlist_fp);
        sscanf(buffer, "%s\t%s\n", galaxies[gal].input_file, galaxies[gal].output_file);
        //fprintf(stdout,"in: %s\t out: %s\n", galaxies[gal].input_file, galaxies[gal].output_file);
    }


    //PSF image
    fits_open_file(&pfptr, PSF_file, READONLY, &status);
    fits_get_img_dim(pfptr, &naxis, &status);
    fits_get_img_size(pfptr, 2, pnaxes, &status);
    if(status){
        fits_report_error(stderr, status);
        exit(1);
    }

    //check that the PSF has odd rows and columns
    if(pnaxes[0] & 1 == 0 || pnaxes[1] & 1 == 0){
        fprintf(stderr, "Error: the PSF image must have an odd number of rows and columns. It's size is (%i, %i).", pnaxes[0], pnaxes[1]);
        exit(1);
    }

    //allocate enough memory for the PSF
    //fprintf(stdout, "Allocating memory for image \"%s\".\n", argv[1]);
    pimage = (float *) calloc (pnaxes[0]*pnaxes[1], sizeof(float));
    if (pimage == NULL){
        fprintf(stderr, "Error allocating memory for PSF.\n");
        exit(1);
    }

    //read in the PSF
    if(fits_read_pix(pfptr, TFLOAT, fpixel, pnaxes[0]*pnaxes[1], NULL, pimage, NULL, &status)){
        fprintf(stderr, "Can't read in image.\n");
        fits_report_error(stderr, status);
        exit(1);
    }
    //fprintf(stdout, "Read in PSF.\n");
    fits_close_file(pfptr, &status);
    int kx = pnaxes[0]/2, ky = pnaxes[0]/2;//half the width and height of the kernel


    for(gal = 0; gal < ngalaxies; gal++){
        //fprintf(stdout, "Starting galaxy %li, in: %s\tout: %s.\n", gal, galaxies[gal].input_file, galaxies[gal].output_file);

        //read in galaxy image
        fits_open_file(&ifptr, galaxies[gal].input_file, READONLY, &status);
        fits_get_img_dim(ifptr, &naxis, &status);
        fits_get_img_size(ifptr, 2, inaxes, &status);
        if(status){
            fits_report_error(stderr, status);
            exit(1);
        }

        //allocate enough memory for the image
        //fprintf(stdout, "Allocating memory for image \"%s\".\n", argv[1]);
        image = (float *) calloc (inaxes[0]*inaxes[1], sizeof(float));
        if (image == NULL){
            fprintf(stderr, "Error allocating memory for galaxy %i image.\n", gal);
            exit(1);
        }

        //read in the image
        if(fits_read_pix(ifptr, TFLOAT, fpixel, inaxes[0]*inaxes[1], NULL, image, NULL, &status)){
            fprintf(stderr, "Can't read in image.\n");
            fits_report_error(stderr, status);
            exit(1);
        }
        //fprintf(stdout, "Read in galaxy %li postage stamp.\n", gal);

        char        xembedstr[32], yembedstr[32];
        long int    xembed, yembed;
        fits_read_key_str(ifptr, "XEMBED", xembedstr, NULL, &status);
        fits_read_key_str(ifptr, "YEMBED", yembedstr, NULL, &status);

        sscanf(xembedstr, "%li", &xembed);
        sscanf(yembedstr, "%li", &yembed);

        //fprintf(stdout, "Read in input image.\n");
        fits_close_file(ifptr, &status);


        //we need to make a border the size of the half the kernel around the postage stamp
        onaxes[0] = inaxes[0] + 2*kx;
        onaxes[1] = inaxes[1] + 2*ky;
        long int row, col;
        

        //make the output image
        oimage = (float *) calloc(onaxes[0]*onaxes[1], sizeof(float));
        if(oimage == NULL){
            fprintf(stderr, "Error allocating memory for output image for galaxy %i.\n", gal);
            exit(1);
        }

        //make arrays for FFTW that are the same size as the output image
        float *GAL, *PSF, *OUT;
        GAL = fftwf_alloc_real(onaxes[0]*onaxes[1]);
        PSF = fftwf_alloc_real(onaxes[0]*onaxes[1]);
        OUT = fftwf_alloc_real(onaxes[0]*onaxes[1]);
        memset(GAL, 0, onaxes[0]*onaxes[1]*sizeof(float));
        memset(PSF, 0, onaxes[0]*onaxes[1]*sizeof(float));
        memset(OUT, 0, onaxes[0]*onaxes[1]*sizeof(float));

        //pad the postage stamp with half the size of the kernel
        //also change to row-major order
        for(row = 0; row < inaxes[0]; row++){
            for(col = 0; col < inaxes[1]; col++){
                GAL[(row+kx)*onaxes[1]+(col+ky)] = image[col*inaxes[0]+row];
            }
        }
        free(image);

        //make PSF with the center pixel of the PSF at (0,0) and wrap around to the other sides
        //also change to row-major order
        for(row = 0; row < pnaxes[0]; row++){
            for(col = 0; col < pnaxes[1]; col++){
                int real_row = (row-kx + onaxes[0]) % onaxes[0]; 
                int real_col = (col-ky + onaxes[1]) % onaxes[1];
                PSF[real_row*onaxes[1]+real_col] = pimage[col*pnaxes[0]+row];
            }
        }
        


        //create FFTW3 variables
        fftwf_complex *FGAL, *FPSF, *FOUT;
        fftwf_plan pGAL, pPSF, pinv;
        float scale = 1.0 / (onaxes[0]*onaxes[1]);

        long int fcol = (onaxes[1]/2)+1;

        FGAL = fftwf_alloc_complex(onaxes[0]*fcol);
        FPSF = fftwf_alloc_complex(onaxes[0]*fcol);
        FOUT = fftwf_alloc_complex(onaxes[0]*fcol);


        pGAL = fftwf_plan_dft_r2c_2d(onaxes[0], onaxes[1], GAL, FGAL, FFTW_ESTIMATE);
        pPSF = fftwf_plan_dft_r2c_2d(onaxes[0], onaxes[1], PSF, FPSF, FFTW_ESTIMATE);
        pinv = fftwf_plan_dft_c2r_2d(onaxes[0], onaxes[1], FOUT, OUT, FFTW_ESTIMATE);

        fftwf_execute(pGAL);
        fftwf_execute(pPSF);

        //fprintf(stderr,"Convolving...\n");

        for(row = 0; row < onaxes[0]; row++){
            for(col = 0; col < fcol; col++){
                long int index = row*fcol + col; //the row-major index
                //do complex multiplication and get the scale right
                FOUT[index][0] = scale*(FGAL[index][0] * FPSF[index][0] - FGAL[index][1] * FPSF[index][1]);
                FOUT[index][1] = scale*(FGAL[index][0] * FPSF[index][1] + FGAL[index][1] * FPSF[index][0]);
            }
        }

        //fprintf(stderr,"Multiplied in fourier space...\n");
        fftwf_execute(pinv);

        //fprintf(stderr, "Took inverse transform...\n");
        fftwf_destroy_plan(pGAL);
        fftwf_destroy_plan(pPSF);
        fftwf_destroy_plan(pinv);

        //fprintf(stderr, "Destroyed FFTW plans...\n");

        for(row = 0; row < onaxes[0]; row++){
            for(col = 0; col < onaxes[1]; col++){
                long int rm_index = row*onaxes[1]+col, cm_index = col*onaxes[0] + row;
                oimage[cm_index] = OUT[rm_index];
            }
        }
        fftwf_free(GAL);
        fftwf_free(PSF);
        fftwf_free(OUT);
        fftwf_free(FGAL);
        fftwf_free(FPSF);
        fftwf_free(FOUT);

        xembed -= kx;
        yembed -= ky;

        //write out output image 
        fits_create_file(&ofptr, galaxies[gal].output_file, &status);
        fits_create_img(ofptr, FLOAT_IMG, naxis, onaxes, &status);
        fits_update_key(ofptr, TLONG, "XEMBED", &xembed , "x pixel in target image to embed lower left pixel.", &status);
        fits_update_key(ofptr, TLONG, "YEMBED", &yembed , "y pixel in target image to embed lower left pixel.", &status);
        fits_write_pix(ofptr, TFLOAT, fpixel, onaxes[0]*onaxes[1], oimage, &status);

        fits_close_file(ofptr, &status);
        fits_report_error(stderr, status);

        free(oimage);
        fprintf(stdout, "Convolved image %i.\n", gal);
    }
    fprintf(stdout,"Success! All images convolved.\n");
    return 0;  
}
