#include <stdio.h>
#include <string.h>
#include <math.h>
#include "fitsio.h"


char *help[] = {
    "usage: jedinoise input_file exp_time noise_mean output_file",
    "Arguments: input_file - FITS file to rescale",
    "           exp_time - the exposure time for the image in seconds(multiplicative factor for the image before noise)",
    "           noise_mean - mean amount of noise",
    "           output_file - output FITS file that will be created",
    0};


int main(int argc, char *argv[]){
    //declare variables
    float exp_time, noise_mean;
    char infile[1024], outfile[1024];

    //fits variables
    fitsfile    *infptr, *outfptr;          //fits pointers for the input and output files
    int         status = 0, naxis = 0;      //cfitsio status counter & image dimensionality
    long        inaxes[2];                  //cfitsio image dimensions array for iamges
    long        fpixel[2] = {1,1};          //cfitsio first/last pixel to read in/out
    float       *image;                     //arrays for the input and output images
    float       *CDF;                       //continuous distribution function 
    long int    CDF_bins;                   //number of bins for the CDF array

    //print help
    if(argc != 5){
        int line;
        for(line = 0; help[line] !=0; line++){
            fprintf(stderr, "%s\n", help[line]);
        }
        exit(1);
    }

    //parse command line input
    sscanf(argv[1], "%s", infile);
    sscanf(argv[2], "%f", &exp_time);
    sscanf(argv[3], "%f", &noise_mean);
    sscanf(argv[4], "%s", outfile);
    CDF_bins = (long int) 10*noise_mean;

    fprintf(stdout,"%s %f %f %s\n", infile, exp_time, noise_mean, outfile);


    //open input image
    fits_open_file(&infptr, infile, READONLY, &status);
    fits_get_img_dim(infptr, &naxis, &status);
    fits_get_img_size(infptr, 5, inaxes, &status);
    if(status){
        fits_report_error(stderr,status);
        exit(1);
    }

    //allocate enough memory for the input image
    image = (float *) calloc (inaxes[0] * inaxes[1], sizeof(float));
    if (image == NULL){
        fprintf(stderr, "Error: cannot allocate memory for input image.\n");
        exit(1);
    }

    //read in the image
    //fprintf(stdout, "Reading in %s, size: %.0fMB. This may take a few minutes for large images.\n", infile, (float) inaxes[0]*inaxes[1]*sizeof(float)/1000000);
    if(fits_read_pix(infptr, TFLOAT, fpixel, inaxes[0]*inaxes[1], NULL, image, NULL, &status)){
        fprintf(stderr, "Error: cannot read in input image.\n");
        fits_report_error(stderr, status);
        exit(1);
    }
    fits_close_file(infptr, &status);


    //make CDF
    CDF = (float *) calloc(CDF_bins, sizeof(float));
    if(CDF == NULL){
        fprintf(stderr, "Error: could not allocate memory for CDF.\n");
        exit(1);
    }
    {
        long int i; //counter
        float prefactor = expf(-noise_mean);
        float partial_sum = 0;
        float factorial;
        for(i = 0; i < CDF_bins; i++){
            factorial = (i == 0 ? 1 : factorial*i);
            partial_sum += pow(noise_mean, i)/factorial;
            CDF[i] = prefactor*partial_sum;
            //fprintf(stdout,"CDF[%li]: %f\n", i, CDF[i]);
        }
    }


    fprintf(stdout, "Adding noise to input image.\n");
    long int row, col;
    for(row = 0; row < inaxes[0]; row++){
        fprintf(stdout, "Noise-ing row %li/%li.\n", row, inaxes[0]);
        for(col = 0; col < inaxes[1]; col++){

            float r = ((float) rand())/RAND_MAX;

            long int j = 0;
            while(CDF[j] <= r && r < CDF_bins)
                j++;
            image[col*inaxes[0]+row] = exp_time*image[col*inaxes[0]+row] + j;
        }
    }



    //write out the output image
    fprintf(stdout,"Writing output image.\n");
    fits_create_file(&outfptr, outfile, &status);
    fits_create_img(outfptr, FLOAT_IMG, naxis, inaxes, &status);
    fits_write_pix(outfptr, TFLOAT, fpixel, inaxes[0]*inaxes[1], image, &status);
    fits_close_file(outfptr, &status);
    fits_report_error(stderr, status);

    free(image);
    return 0;
}

